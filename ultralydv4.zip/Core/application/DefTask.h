/*
 * DefTask.h
 *
 *  Created on: Feb 20, 2023
 *      Author: MadsB
 */

#ifndef APPLICATION_DEFTASK_H_
#define APPLICATION_DEFTASK_H_

void deftask_init();

#endif /* APPLICATION_DEFTASK_H_ */

