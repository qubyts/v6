/*
 * Myapp.c
 *
 *  Created on: Feb 2, 2023
 *      Author: MadsB
 */


#include "main.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "usart.h"
#include "stdbool.h"
#include "FreeRTOS.h"
#include "stm32f4xx_hal_conf.h"
#include "cmsis_os2.h"
#include "usart.h"
#include "BuzzerTask.h"
#include "DefTask.h"
#include "print_server.h"


void Myapp(void){




};
