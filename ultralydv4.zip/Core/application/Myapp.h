/*
 * Myapp.h
 *
 *  Created on: Feb 2, 2023
 *      Author: MadsB
 */

#ifndef MYAPP_H_
#define MYAPP_H_

void Myapp(void);

#endif /* APPLICATION_MYAPP_H_ */
