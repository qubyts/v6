#ifndef BUZZER_H
#define BUZZER_H

void buzzer_init();

#endif
